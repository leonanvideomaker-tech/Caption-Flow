@echo off
REM ====================================================================
REM  Caption Flow Free - Instalador (Windows)
REM  Instala a extensao e libera as extensoes externas do Premiere.
REM  Nao precisa de internet nem de nada alem de um duplo-clique.
REM ====================================================================
setlocal
cd /d "%~dp0"
title Caption Flow Free - Instalacao

set "ZIP=%~dp0Caption Flow Free.zip"
set "EXT_DIR=%APPDATA%\Adobe\CEP\extensions"
set "DEST=%EXT_DIR%\Caption Flow Free"

cls
echo.
echo   ============================================
echo         CAPTION FLOW FREE - INSTALACAO
echo   ============================================
echo.

REM 1. Premiere precisa estar fechado
tasklist /FI "IMAGENAME eq Adobe Premiere Pro.exe" 2>NUL | find /I "Adobe Premiere Pro.exe" >NUL
if not errorlevel 1 (
    echo   [!] O Premiere Pro esta ABERTO.
    echo       Feche o Premiere e rode este instalador de novo.
    echo.
    pause
    exit /b 1
)

REM 2. Conferir o arquivo da extensao
if not exist "%ZIP%" (
    echo   [X] Nao encontrei o arquivo "Caption Flow Free.zip" nesta pasta.
    echo       Mantenha este instalador na MESMA pasta que o .zip.
    echo.
    pause
    exit /b 1
)

REM 3. Instalar (remove versao antiga e descompacta)
echo   - Instalando a extensao...
if not exist "%EXT_DIR%" mkdir "%EXT_DIR%"
if exist "%DEST%" rmdir /s /q "%DEST%"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "try { Expand-Archive -LiteralPath '%ZIP%' -DestinationPath '%EXT_DIR%' -Force } catch { exit 1 }"
if errorlevel 1 (
    echo   [X] Falha ao descompactar a extensao.
    pause
    exit /b 1
)

REM 4. Liberar extensoes externas (PlayerDebugMode) - Premiere 2018 -> 2026+
echo   - Liberando extensoes externas do Premiere...
for %%v in (6 7 8 9 10 11 12 13 14 15) do (
    reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >NUL 2>&1
)

echo.
echo   [OK] Caption Flow Free instalado com sucesso!
echo.
echo   Agora:
echo    1. Abra o Premiere Pro
echo    2. Menu  Janela ^> Extensoes ^> Caption Flow Free
echo    3. Pronto - sem chave, sem cadastro, so usar!
echo.
pause
endlocal
