#!/bin/bash
# ════════════════════════════════════════════════════════════════════
#  Caption Flow Free — Instalador (Mac)
#  Instala a extensão e libera as extensões externas do Premiere.
#  Não precisa de internet, Python ou nada além de um duplo-clique.
# ════════════════════════════════════════════════════════════════════

DIR="$(cd "$(dirname "$0")" && pwd)"
ZIP="$DIR/Caption Flow Free.zip"
EXT_DIR="$HOME/Library/Application Support/Adobe/CEP/extensions"
DEST="$EXT_DIR/Caption Flow Free"

clear
echo ""
echo "  ╔══════════════════════════════════════════╗"
echo "  ║      CAPTION FLOW FREE — INSTALAÇÃO      ║"
echo "  ╚══════════════════════════════════════════╝"
echo ""

# 1. Premiere precisa estar fechado
if pgrep -i "Adobe Premiere Pro" >/dev/null 2>&1; then
    echo "  ⚠️  O Premiere Pro está ABERTO."
    echo "     Feche o Premiere e rode este instalador de novo."
    echo ""
    read -p "  Pressione ENTER para sair..."
    exit 1
fi

# 2. Conferir o arquivo da extensão
if [ ! -f "$ZIP" ]; then
    echo "  ❌ Não encontrei o arquivo 'Caption Flow Free.zip' nesta pasta."
    echo "     Mantenha este instalador na MESMA pasta que o .zip."
    echo ""
    read -p "  Pressione ENTER para sair..."
    exit 1
fi

# 3. Instalar (remove versão antiga e descompacta)
echo "  → Instalando a extensão..."
mkdir -p "$EXT_DIR"
rm -rf "$DEST"
if ! /usr/bin/unzip -o -q "$ZIP" -d "$EXT_DIR"; then
    echo "  ❌ Falha ao descompactar a extensão."
    read -p "  Pressione ENTER para sair..."
    exit 1
fi

# 4. Liberar extensões externas (PlayerDebugMode) — Premiere 2018 → 2026+
echo "  → Liberando extensões externas do Premiere..."
for v in 6 7 8 9 10 11 12 13 14 15; do
    defaults write "com.adobe.CSXS.$v" PlayerDebugMode 1 2>/dev/null
done
killall cfprefsd 2>/dev/null

echo ""
echo "  ✅ Caption Flow Free instalado com sucesso!"
echo ""
echo "  Agora:"
echo "   1. Abra o Premiere Pro"
echo "   2. Menu  Janela ▸ Extensões ▸ Caption Flow Free"
echo "   3. Pronto — sem chave, sem cadastro, só usar!"
echo ""
read -p "  Pressione ENTER para fechar."
